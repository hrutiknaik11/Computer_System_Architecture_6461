package main.java.com.gwu.csa;

import main.java.com.gwu.csa.gui.GUI;

public class CsaApp {

    /**
     * Entry point of project
     * @param args
     */
    public static void main(String[] args) {
        new GUI();
    }
}
